package base_class;

public class data {
	public String TC_ID;
	public String KeyWord;
	public String XPath;
	public String Test_Data;
}
