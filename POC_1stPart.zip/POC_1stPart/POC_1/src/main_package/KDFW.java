package main_package;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import base_class.all_methods;
import base_class.data;
import base_class.test_data;
import utilities.excel_read;
import utilities.excel_write;

public class KDFW {
	static Logger log;
	static data d=new data();
	static test_data td=new test_data();
	public static void main(String a[]) throws IOException {
		File f=new File("D://poc.xlsx");		
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Keyword");
		log=Logger.getLogger("devpinoyLogger");
		String id,ch;
		int i,j,k;
		for(i=1;i<=3;i++) {
			td=excel_read.read_sheet1(i);
			System.out.println(td.flag);
			if(td.flag.equals("Y"))
			{
				for(j=1;j<=sh.getLastRowNum()-1;j++) {
					id=excel_read.read_ids(j);
					System.out.println(id);
					if(id.equals(td.id))
						{System.out.println("yes");
						break;}
					else 
						continue;
				}
				for(k=j;k<=((j+td.steps)-1);k++) {
					d=excel_read.read_sheet2(k);
					ch=d.KeyWord;
					System.out.println(d.KeyWord);
					switch(ch) {
						case "launchBrowser": all_methods.launchBrowser(d.XPath);
											  log.info("Browser launched");
											  break;
						case "enterText" : all_methods.enter_text(d.XPath,d.Test_Data);
											log.info("Text entered");
											break;
						case "clickButton": all_methods.clickButton(d.XPath);
											log.info("Button Clicked");
											break;
						case "clickLink" :all_methods.clickButton(d.XPath);
											log.info("Link Clicked");
											break;
						case "clickRadioButton":all_methods.r_sex(d.Test_Data);
											log.info("Sex Clicked");
												break;
						case "verify"  : excel_write.write_sheet2(k,all_methods.verify(d.XPath,d.Test_Data));
											System.out.println(k + " "+all_methods.verify(d.XPath,d.Test_Data));
											log.info("Verified");
											break;
					}
					
				
				}
				if(k==(j+td.steps))
				{	System.out.println( i+"pass");
					excel_write.write_sheet1(i, "pass");}
				else
					{System.out.println( i+ "fail");
					excel_write.write_sheet1(i, "fail");}
			}
				
		}
	}
}
