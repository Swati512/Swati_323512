//Name:-Swati Kumari
//Write a program on logical operators
//===============================================================

package prime;

public class logical {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int c=5,a=10,b=20;
    System.out.println((a>b) && (a>c));
    System.out.println((a>b) || (a>c));
    System.out.println(!((a>b) || (a>c)));
	}

}
