//Name:-Swati Kumari
//Write a program on relational operator
//===============================================================

package prime;

public class relpro {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=5,a=10,b=5;
		System.out.println(a<b);
		System.out.println(b>c);

	}

}
