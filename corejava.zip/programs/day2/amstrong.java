//Name:-Swati Kumari
//Write a program on armstrong number 
//===============================================================

package pkg_1;

import java.util.Scanner;

public class amstrong {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.println("enter a integer value");
		int a=input.nextInt();
		System.out.println(a);
		int z=a;
		double sum=0;
		String s=Integer.toString(a);
		while(a>0)
		{
			int y=a%10;
			a=a/10;
			sum=sum+Math.pow(y, s.length());
			
		}
		if(z==sum)
		{
			System.out.println("amstrong number");
		}
	
    
	}

}
