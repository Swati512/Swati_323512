Name:-Swati Kumari
Write a program on finding sum of array elements
===============================================================
package pkg_1;

public class arrayi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] m={91,92,86,89,94};
int sum=0,avg=0;
for(int i=0;i<=4;i++)
{
	sum=sum+m[i];
}
avg=sum/5;
for(int i=0;i<=4;i++)
{
	if(m[i]>avg)
	{
		System.out.println(m[i]);
	}
}
	}

}
