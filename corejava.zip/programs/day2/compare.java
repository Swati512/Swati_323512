Name:-Swati Kumari
Write a program on finding vowels and consonent
===============================================================
package pkg_1;

import java.util.Scanner;

public class compare {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner input=new Scanner(System.in);
	System.out.println("enter a character");
	char ch=input.next().charAt(0);
	System.out.println(ch);
	
	if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' )
	{
		System.out.println("vowel");
	}
	else
	{
		System.out.println("consonent");
	}
	
	
	}

}
