Name:-Swati Kumari
Write a program on sum of numbers which are divisible by 3
===============================================================
package pkg_1;

public class div3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int sum=0;
   for(int i=10;i<=30;i++)
   {
	   if(i%3==0)
	   {
		   System.out.println(i);
		   sum=sum+i;
	   }
   }
   System.out.println(sum);
	}

}
