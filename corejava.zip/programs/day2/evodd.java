Name:-Swati Kumari
Write a program on finding even or odd number
===============================================================
package pkg_1;

import java.util.Scanner;

public class evodd {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
Scanner input=new Scanner(System.in);
System.out.println("enter a integer value");
int a=input.nextInt();
System.out.println(a);
if(a%2==0)
{
	System.out.println("even number");
}
else
{
	System.out.println("odd number");
}
	}

}
