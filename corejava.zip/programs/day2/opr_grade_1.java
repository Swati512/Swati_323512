Name:-Swati Kumari
Write a program to find whether student passed a exam or not
===============================================================
package pkg_1;

public class opr_grade_1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     float marks=75.0f;
     if(marks>=75.0)
     {
    	 System.out.println("FCD");
     }
     else if(marks>=60.0)
     {
    	 System.out.println("FC");
     }
     else if(marks>=50.0)
     {
    	 System.out.println("SC");
     }
     else if(marks>=35)
     {
    	 System.out.println("PC");
     }
     else
     {
    	 System.out.println("fail");
     }
	}

}
