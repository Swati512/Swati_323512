Name:-Swati Kumari
Write a program to print a pattern
===============================================================
package pkg_1;

public class p1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    for(int j=1;j<=3;j++)
    {
    	for(int i=1;i<=j;i++)
    	{
    		System.out.print("1 ");
    	}
    	System.out.println();
    	//System.out.println();
    	
    }
    System.out.println();
    for(int j=1;j<=3;j++)
    {
    	for(int i=1;i<=j;i++)
    	{
    		System.out.print(i);
    		System.out.print(" ");    	}
    	System.out.println();
    }
	
	 for(int j=1;j<=3;j++)
	    {
		 for(int l=1;l<=3-j;l++)
		 {
			 System.out.print(" ");
		 }
	    	for(int i=1;i<=j;i++)
	    	{
	    		System.out.print(i);
	    		//System.out.print(" "); 
	    	}
	    	System.out.println();
	    
		}
}
}

