Name:-Swati Kumari
Write a program to find sum as per unit
===============================================================
package pkg_1;

public class ques2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    float units=225.0f;
    double sum=0.0f;
    if(units<=100)
    {
    	sum=(units*1.5);
    }
    else if(units>100 && units<=200)
    {
    	sum=(100*1.5)+(units-100)*2.0;
    }
    else if(units>200 && units<=250)
    {
    	sum=(100*1.5)+(100*2.0)+(units-200)*2.5;
    }
    else
    {
    	sum=(100*1.5)+(100*2.0)+(50*2.5)+((units-250)*4.0);
    }
    System.out.println(sum);
	}

}
