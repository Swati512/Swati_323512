Name:-Swati Kumari
Write a program to take the information of a student
===============================================================
package pkg_1;
import java.util.Scanner;

public class ques3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum1=0;
		float avg=0.0f;
		Scanner input=new Scanner(System.in);
		//System.out.println("enter a integer value");
		for(int j=0;j<3;j++)
		{
			System.out.println("enter the name");
		for(int i=0;i<4;i++)
		{
			System.out.println("enter a integer value");
		int a=input.nextInt();
		System.out.println(a);
		sum1=sum1+a;
		}
		avg=sum1/4;
		System.out.println(sum1);
		System.out.println(avg);
		}
	}

}
