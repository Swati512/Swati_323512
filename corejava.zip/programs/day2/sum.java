Name:-Swati Kumari
Write a program on counting of characters in a string
===============================================================
Name:-Swati Kumari
Write a program on finding array number whose sum is 65
===============================================================
package pkg_1;

public class sum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]={21,15,34,91,50,16,44};
for(int i=0;i<=6;i++)
{
	for(int j=0;j<=6;j++)
	{
		if(a[i]+a[j]==65)
		{
			System.out.println(a[i]+" "+a[j]);
		}
	}
}

	}

}
