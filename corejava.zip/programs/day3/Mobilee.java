package pkg_1;

public class Mobilee {
 
	String color;
	float len;
	float breadth;
	String brand;
	public void call()
	{
		System.out.println("mobile is calling");
	}
	public void msg()
	{
		System.out.println("mobile is msging");
	}
	public void displaydetails()
	{
		System.out.println("color= " + color);
	}
	/*System.out.println(smg.brand);
	System.out.println(smg.color);
	
	public void displaydetails()
	{
		System.out.println()
	}*/
	
}
