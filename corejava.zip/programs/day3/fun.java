package pkg_1;

public class fun {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10,b=20,c;
c=add(a,b);
System.out.println(c);

	}
	public static int add(int x,int y)
	{
		int z=x+y;
		return z;
	}

}
