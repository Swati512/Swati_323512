package pkg_1;

public class mobile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Mobilee smg=new Mobilee();
smg.color="black";
smg.len=4;
smg.breadth=1;
smg.brand="samsung";
smg.call();
smg.msg();
smg.displaydetails();
	}

}
