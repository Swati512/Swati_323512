package pkg_1;

public class account {
int accountno;
float accountbal;
float int_rate;

public account(int accountno)
{
	this.accountno=accountno;
}
public account(int accountno,float accountbal,float int_rate)
{
	this.accountno=accountno;
	this.accountbal=accountbal;
	this.int_rate=int_rate;
}


public String get_account_det()
{
	String str= "Account number :" + accountno +"\n"+ "Account balance : " + accountbal +"\n" + "Interest Rate : " +int_rate;
  return str;
}
public float calculateInterest(float amt)
{
	return amt *int_rate/100;
}
}
