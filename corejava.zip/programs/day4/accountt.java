package pkg_1;

public class accountt {
 private int acc_no;
 private float acc_blc;
public int getAcc_no() {
	return acc_no;
}
public void setAcc_no(int acc_no) {
	this.acc_no = acc_no;
}
public float getAcc_blc() {
	return acc_blc;
}
public void setAcc_blc(float acc_blc) {
	this.acc_blc = acc_blc;
}
}
