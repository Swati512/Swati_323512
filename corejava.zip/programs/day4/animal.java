package pkg_1;

public class animal {

}
