package pkg_1;

public class bank {
public float get_roi()
{
	return 0f;
}
}
