package pkg_1;

public class city extends bank {
	public float get_roi()
	 {
		 return 9.5f;
	 }
}
