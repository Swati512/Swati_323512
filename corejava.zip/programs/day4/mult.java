package pkg_1;

public class mult {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=5,j=4;i<=7;i++,j=j+2)
{
	int k=i*j;
	System.out.println(i +"*"+ j +"="+ k);
}
	}

}
