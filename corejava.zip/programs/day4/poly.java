package pkg_1;

public class poly {

	/**
	 * @param args
	 * @return 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	
		polyy pp=new polyy();
	//int i=pp.add(3,4);
	System.out.println(pp.add(3,4));
	System.out.println(pp.add(3,4,7));
	System.out.println(pp.add(3.2,4.6));
	

	
		
	}
}
