package pkg_1;

public class polyy {
	int add(int a,int b)
	{
		int z;
		z=a+b;
		return z;
	}
	int add(int x,int y,int z)
	{
		int m=x+y+z;
		return m;
	}
	double add(double x,double y)
	{
		double l=x+y;
		return l;
	}
	
}
