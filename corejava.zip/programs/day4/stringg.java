package pkg_1;

public class stringg {

	/**
	 * @param args
	 * @param charAt 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="I am learning java ",s1="hello",s2="Hello",s3;
/*int i=s.length();
System.out.println(i);
System.out.println(s1.compareTo(s2));//compareto is case sensitive and it will give 0 if same otherwise some digits acrdng to ascii value
System.out.println(s1.compareToIgnoreCase(s2));
	System.out.println(s.substring(0,4));
	System.out.println(s.indexOf('a',3));//return -1 if that char is not present
	/*int p=0,j=0,c=0,i=0;
	while(p!=-1){
	p=s.indexOf('a',i);
	i=p+1;
	c++;
	}*/
	for(int l=0;l<s.length();l++)
	{
		
		int p=s.indexOf(' ',l);
		 String s4=s.substring(l,p);
		 l=p;
		 System.out.println(s4);
	}
	
	}

	

}
