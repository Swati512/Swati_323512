package pkg_1;

public class test_accountt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
accountt acc1=new accountt();
acc1.setAcc_no(1234);
acc1.setAcc_blc(100);
System.out.println("account blc is " + acc1.getAcc_blc());
System.out.println("account no is " + acc1.getAcc_no());
	}

}
//if we dont want to edit the blc or no so we dont need to give setter