package pkg_1;

public class childclass_1 extends parentclass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//parentclass pc1=new parentclass();
System.out.println(pc1.a);
System.out.println(pc1.b);
System.out.println(pc1.c);
System.out.println(pc1.d);
display();

	}

}
