package pkg_2;

import pkg_1.parentclass;

public class childclass_2 extends parentclass {
	public static void main(String[] args) {
		//parentclass pc=new parentclass();
		/*System.out.println(pc.a);
		System.out.println(pc.b);
		System.out.println(pc.c);
		System.out.println(pc.d);*/
	}
		public void details()
		{
			//System.out.println(a);
			//System.out.println(b);
			System.out.println(c);
			System.out.println(d);
		}

}
