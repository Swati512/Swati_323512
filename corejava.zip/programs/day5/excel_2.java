package pkg_2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_2 {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		try {
			File f=new File("C:\\Users\\swati.kumari1\\Desktop\\java\\excl.xlsx");
			FileInputStream fis;
			fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
		    
		
		} catch(IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
