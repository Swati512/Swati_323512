package pkg_2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io_1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	File f=new File("C:\\Users\\swati.kumari1\\Desktop\\java\\sel.xlsx");
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	XSSFRow row1=sh.createRow(2);
	XSSFCell cell=row1.createCell(0);
	cell.setCellValue("global");
	/*XSSFRow row=sh.getRow(1);
	XSSFCell cell=row.getCell(0);
	String s=cell.getStringCellValue();*/
	//System.out.println("Date : " + s);
	
	FileOutputStream fos=new FileOutputStream(f);
	//cell.setCellValue("noida");
	wb.write(fos);
} /*catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} */catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

}
