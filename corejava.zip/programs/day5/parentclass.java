package pkg_1;

public class parentclass {
	
private static int a=10;
int b=20;
protected int c=30;
public int d=40;
public static void display()
{
	System.out.println(a);
}
}


