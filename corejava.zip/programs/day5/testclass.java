package pkg_2;

public class testclass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
childclass_2 cc=new childclass_2(); 
cc.details();
	}

}
