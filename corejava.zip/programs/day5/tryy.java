package pkg_1;

public class tryy {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10,b=0,c;
System.out.println(a);
//c=a/b;
//System.out.println(a);
//System.out.println(c);

int b1[]={4,6,7,3,8};
try
{
	System.out.println(b1[2]);
	System.out.println(b1[5]);
	System.out.println("hi");
}
catch(Exception e)
{
	System.out.println("inside catch");
}
catch()
{
	
}
System.out.println("outside catch");
	}

}
