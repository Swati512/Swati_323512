package pkg_2;

abstract class abs {
int eid;
String name;
int rateperunit;

public abstract int calc_mnthly_salary();
void emp(int eid,String name,int rateperunit)
{
	this.eid=eid;
	this.name=name;
	this.rateperunit=rateperunit;
}

public abs(int eid, String name, int rateperunit) {
	super();
	this.eid = eid;
	this.name = name;
	this.rateperunit = rateperunit;
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getRateperunit() {
	return rateperunit;
}
public void setRateperunit(int rateperunit) {
	this.rateperunit = rateperunit;
}
}
