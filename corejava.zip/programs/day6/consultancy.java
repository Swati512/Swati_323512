package pkg_2;

class consultancy extends abs {
int totalhrsworked;
public int calc_mnthly_salary()
{
	int sal;
	sal=totalhrsworked*rateperunit;
	return sal;
}
consultancy(int totalhrsworked,int eid,String name,int rateperunit)
{
	super(eid,name,rateperunit);
	this.totalhrsworked=totalhrsworked;
}
}
