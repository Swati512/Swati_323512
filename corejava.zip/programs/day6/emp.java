package pkg_2;

public class emp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
consultancy c=new consultancy(190,1235,"swati",301);
int x=c.calc_mnthly_salary();
System.out.println("salary " + x);

	}

}
