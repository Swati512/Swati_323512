package pkg_2;

public class empl {
static int b=0;
int c=0;
public empl()
{
	c++;
	b++;
}
}
//static var doesnot create in object,it create in separate part of memory
