package pkg_2;

class fte extends abs{
int totaldaysworked;
public int calc_mnthly_salary()
{
	int sal;
	sal=totaldaysworked*rateperunit;
	return sal;
}
public fte(int totaldaysworked,int eid,String name,int rateperunit)
{
	super(eid,name,rateperunit);//super keyword calls constructor of parent class
	this.totaldaysworked=totaldaysworked;
}
}
