package pkg_1;

public class student {
String name1;
int g1,g2,avg1;
public void avg1()
{
	avg1=(g1+g2)/2;
	System.out.println(avg1);
}
/*public void avg2()
{
	avg2=(s1+s2)/2;
	System.out.println(avg2);
}*/

}
