package pkg_1;

public class studentt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
student girish=new student();
student suresh=new student();
girish.name1="girish";
suresh.name1="suresh";
girish.g1=20;
girish.g2=30;
suresh.g1=10;
suresh.g2=50;
girish.avg1();
suresh.avg1();
if(girish.avg1>suresh.avg1)
{
	System.out.println("name is +" girish.name1 "maximum marks is +" girish.avg1());
	
}


/*student x1=new student();
x1.name1="Girish";
x1.name2="Suresh";
x1.g1=12;
x1.g2=23;
x1.s1=45;
x1.s2=10;
x1.avg1();
x1.avg2();
x1.displaydetails();*/
	}

}
