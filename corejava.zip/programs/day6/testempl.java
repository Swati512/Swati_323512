package pkg_2;

public class testempl {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
empl e1=new empl();
System.out.println(e1.b+ " "+e1.c);
empl e2=new empl();
System.out.println(e2.b+ " "+e2.c);
	}

}
