package testing1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class assnt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<studentassnt> ar=new ArrayList<studentassnt>();
		int sid=0;
		String sname=null;
		int java= 0;
		int sel=0;
		for(int i=1;i<=3;i++)
		{
			for(int j=0;j<4;j++)
			{
				try
				{
					File f=new File("C:\\Users\\swati.kumari1\\Desktop\\programs\\studentdata.xlsx");
					FileInputStream fis=new FileInputStream(f);
					XSSFWorkbook wb=new XSSFWorkbook(fis);
					XSSFSheet sh=wb.getSheet("Sheet1");
					XSSFRow row=sh.getRow(i);
					XSSFCell cell=row.getCell(j);
					if(j==0)
					{
						sid=(int)cell.getNumericCellValue();
						System.out.println("sid: "+ sid);
					}
					if(j==1)
					{
						sname=cell.getStringCellValue();
						System.out.println(" sname: "+ sname);
					}
					if(j==2)
					{
						java=(int)cell.getNumericCellValue();
						System.out.println("java marks: "+java);
					}
					if(j==3)
					{
						sel=(int)cell.getNumericCellValue();
						System.out.println("sel marks:"+ sel);
					}
				}
				catch (Exception e)
				{
					// TODO Auto-generated catch block
					System.out.println(e);
				}
			}
	System.out.println();
	studentassnt s1=new studentassnt(sid,sname,java,sel);
	ar.add(s1);
		}
		int counter=1;
		for(studentassnt std:ar)
		{
			System.out.println(std.java);
			try
			{
				File f=new File("C:\\Users\\swati.kumari1\\Desktop\\programs\\studentdata.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow row1=sh.getRow(counter);
				XSSFCell celld=row1.createCell(4);
				celld.setCellValue((std.java+std.sel)/2);
				XSSFCell celle=row1.createCell(5);
				int avg=(java+sel)/2;
				if(avg<35)
				{
					celle.setCellValue("F");
				}
				else if(avg<50)
				{
					celle.setCellValue("pass");
				}
				else if(avg<50)
				{
					celle.setCellValue("2nd division");
				}
				else if(avg<60)
				{
					celle.setCellValue("1st division");
				}
				else
				{
					celle.setCellValue("FDH");
				}
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
				counter++;
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}


	}

}
