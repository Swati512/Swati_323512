package testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://demowebshop.tricentis.com");
		String s1="Demo Web Shop";
		String s=dr.getTitle();
		
		if(s1.equals(s))
		{
			System.out.println("It matched");
			System.out.println(s);
		}
		dr.findElement(By.className("ico-register")).click();
		java.util.List<WebElement> rb=dr.findElements(By.name("Gender"));
		((WebElement)rb.get(1)).click();
		dr.findElement(By.xpath("// input[@id='FirstName']")).sendKeys("Swati");
		dr.findElement(By.xpath("// input[@id='LastName']")).sendKeys("Kumari");
		dr.findElement(By.xpath("// input[@id='Email']")).sendKeys("sweetswati37@gmail.com");
		dr.findElement(By.xpath("// input[@id='Password']")).sendKeys("pass123$");
		dr.findElement(By.xpath("// input[@id='ConfirmPassword']")).sendKeys("pass123$");
		dr.findElement(By.id("register-button")).click();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[2]/input")).click();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.close();
}

}