package testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String s1="Online Bookstore";
		String s=dr.getTitle();
		if(s1.equals(s))
		{
			System.out.println("It matches");
			System.out.println(s);
		
		}
		
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select")).click();
	    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
	    //dr.close();
	    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
	    String s2="Web Database Development";
	    String s3=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
	    if(s2.contentEquals(s3))
	    {
	    	System.out.println("matched");
	    }
	    
	}

}
