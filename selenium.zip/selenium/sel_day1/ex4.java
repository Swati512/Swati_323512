package testing1;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<exx4> ar = new ArrayList<exx4>();
		
		String email;
		String pass;
		String expec_result;
		String file_path = "Desktop\\java\\ex4.xlsx";
		
		methods met = new methods();
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com");
		
		for(int i=1;i<4;i++)
		{
				email = met.read(i, 0, file_path );
				pass = met.read(i, 1, file_path);
				expec_result = met.read(i, 2, file_path);
				exx4 o = new exx4(email,pass,expec_result);
				System.out.println(o.email + o.pass);
				ar.add(o);
		}
		
		
		int counter=1;
		for(exx4 i: ar)
		{
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(i.email);
			//System.out.println(i.email + i.pass);
			dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(i.pass);
			
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			
			String data = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
			if(i.expec_result == data)
			{
				met.write(counter, 3, file_path, "login successful");
			}
			else
			{
				met.write(counter, 3, file_path, "login failed");
			}
			counter++;
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		}
		
		dr.close();
		

	}

}
