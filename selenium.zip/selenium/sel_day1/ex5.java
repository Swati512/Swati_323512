package testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select")).click();
	    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select/option[3]")).click();
	    
	    dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
	    String s2="Web Database Development";
	    String s3=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
	    if(s2.contentEquals(s3))
	    {
	    	System.out.println("matched");
	    }
		
		String s4=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText();
		String s5=s4.substring(8,13);
		//System.out.println(s5);
		float f=Float.parseFloat(s5);
		System.out.println(f);	
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]"));
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys("2");
		
		//dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/text()"));
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();
		dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();
		
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select/option[4]"));
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[3]/td[2]/b/a")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys("3");
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[4]/td/input")).click();
		//dr.close();
	}
	

}
