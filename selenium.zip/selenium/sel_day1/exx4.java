package testing1;

public class exx4 {

	String email;
	String pass;
	String expec_result;
	public exx4(String email, String pass, String expec_result) {
		this.email = email;
		this.pass = pass;
		this.expec_result = expec_result;
	}
}
