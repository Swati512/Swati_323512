package testing1;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class methods {
	/*public boolean prime(int n)
	{
		int flag=0;
		
		if (n > 1)
		{
			
			for(int i =2; i<= Math.sqrt(n); i++)
			{
				if (n%i==0)
				{
					flag=1;
					break;
				}
			}
		}
		
		if (flag==0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean even(int n)
	{
		if (n%2==0)
			return true;
		else
			return false;
	}
	*/
	@SuppressWarnings("resource")
	public String read(int x, int y ,String file_path )
	{
		String result=null;
		try
		{
			File f = new File(file_path);
			FileInputStream  fis = new FileInputStream(f);
			XSSFWorkbook wb =  new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row = sh.getRow(x);
			XSSFCell cell = row.getCell(y);
			result = cell.getStringCellValue();
			
//			result = (int)cell.getNumericCellValue();

		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("not reading");
		}
		
		return result;
	
	}
	
	public void write(int x, int y, String file_path, String data )
	//public boolean write(int x, int y, String str, String data )
	{
		//boolean flag=false;
		try
		{
			//File f = new File("D:\\FirstSheet.xlsx");
			File f = new File(file_path);
			FileInputStream  fis = new FileInputStream(f);
			XSSFWorkbook wb =  new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row1 = sh.getRow(x);
			XSSFCell celld = row1.createCell(y);
			//System.out.println("hi ");
			
			celld.setCellValue(data);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			//flag = true;
		}
		catch(Exception e)
		{
			System.out.println(e);
			//flag = false;
		}
		
		//return flag;
	
	}
}
