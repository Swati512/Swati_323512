package testing1;

public class studentassnt {
	int sid;
	String sname;
	int java;
	int sel;
	public studentassnt(int sid,String sname,int java,int sel)
	{
		super();
		this.sid=sid;
		this.sname=sname;
		this.java=java;
		this.sel=sel;
	}
	}

