package testing1;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class t1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.gmail.com");
		//dr.findElement(By.id("email")).sendKeys("girishindia95@gmail.com");
		//dr.findElement(By.id("pass")).sendKeys("newfbp@55");
		//dr.findElement(By.id("loginbutton")).click();
		//WebElement we=dr.findElements(By.xpath(""));
		//we.get(0).click();
		
		//for radio button
		/*List rb=dr.findElements(By.name("sex"));
		((WebElement)rb.get(2)).click();//rb is a list type
		((WebElement)rb.get(0)).click();*/
		
		boolean cs=dr.findElement(By.xpath("//*[@id=\":m6\"]")).isSelected();
		boolean fs=true;
		if(cs==false)
		{
			if(fs==true)
			{
				dr.findElement(By.xpath("//*[@id=\":m6\"]")).click();
			}
		}
		else
		{
			if(fs==false)
			{
				dr.findElement(By.xpath("//*[@id=\":m6\"]")).click();
			}
		}
	}

}
