package testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
public class t2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
WebDriver dr= new ChromeDriver();
dr.get("https://www.facebook.com");*/
		
		
/*dr.findElement(By.cssSelector("input[type='submit']")).click();
dr.findElement(By.xpath(" // input[@id='email']")).sendKeys("sweetswati@gmail.com");
dr.findElement(By.xpath(" // input[@id='pass']")).sendKeys("sssss");*/
		
/*String s=dr.findElement(By.xpath("//*[contains(text(),'Create an account')]")).getText();
System.out.println(s);
System.out.println("helloo");*/
		
/*System.setProperty("webDriver.ie.driver","IEDriverServer.exe");
WebDriver dr1=new InternetExplorerDriver();
dr1.get("https://www.facebook.com");*/
		
System.setProperty("webdriver.gecko.driver","geckodriver.exe");
WebDriver dr2=new FirefoxDriver();
dr2.get("https://www.facebook.com");

	}
}
