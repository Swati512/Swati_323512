package sel_day2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ex4 {

	public static void displayy() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
      
		public String read(int x, int y)
		{
       File f=new File("D:\\res.xlsx");
       FileInputStream fis=new FileInputStream(f);
       XSSFWorkbook wb=new XSSFWorkbook(fis);
       XSSFSheet sh = wb.getSheet("Sheet1");
		String s=sh.getRow(x).getCell(y).getStringCellValue();
		String s1=sh.getRow(x).getCell(y).getStringCellValue();
		String s2=sh.getRow(x).getCell(y).getStringCellValue();
		
		}
		
		    File f1 = new File("D:\\res.xlsx");
			FileInputStream  fis1 = new FileInputStream(f1);
			XSSFWorkbook wb1 =  new XSSFWorkbook(fis1);
			XSSFSheet sh1 = wb1.getSheet("Sheet1");
			XSSFRow row1 = sh1.getRow(1);
			XSSFCell celld = row1.createCell(3);
			
			celld.setCellValue(dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText());
			FileOutputStream fos=new FileOutputStream(f1);
			wb1.write(fos);
			
			
			/*String s8=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			System.out.println(s8);
			if(s2.equals(s8))
			{
				System.out.println(s2);
				
			}
			else
			{
				File f11 = new File("D:\\res.xlsx");
				FileInputStream  fis11 = new FileInputStream(f11);
				XSSFWorkbook wb11 =  new XSSFWorkbook(fis11);
				XSSFSheet sh11 = wb11.getSheet("Sheet1");
				XSSFRow row11 = sh11.getRow(1);
				XSSFCell celld1 = row11.createCell(4);
				
				celld1.setCellValue("Wrong");
				FileOutputStream fos1=new FileOutputStream(f11);
				wb11.write(fos1);
			}	*/	
	}
	
}


