package sel_day3;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sel_21 {
	
	
	public static void display()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://demo.guru99.com/test/delete_customer.php");
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys("giri");
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]")).click();
		
		
		Alert a=dr.switchTo().alert();
		String Alert_msg=a.getText();
		System.out.println(Alert_msg);
		a.accept();
		String a_msg=a.getText();
		System.out.println(a_msg);
		a.dismiss();
		
		
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys("giri123");
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]")).click();
		Alert a1=dr.switchTo().alert();
		String Alert_msg1=a.getText();
		System.out.println(Alert_msg1);
		a.dismiss();
		dr.close();
		
		
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
	}

}
