package sel_day3;

import org.testng.annotations.Test;

public class testing_tc2 extends sel_21 {
  @Test
  public void f() {
	  display();
	  System.out.println("in f");
	  
  }
}
