package sel_day3;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

//import sel_day2.ex4;
import sel_day2.login;

public class testing_tc3  {
	
	//login lg=new login();
	@Test
 public void test1() {
	  
 //String ar=login.loginn();
		 
String err="NOIDA",ar="NOIDA";
	 System.out.println("in test1");
	 Assert.assertEquals(ar,err);
	 System.out.println("after assert - in test1");
	 }
	 
  @Test
  public void test2() {
	  
	  String err="NOIDA",ar="NOID";
	  System.out.println("in test2");
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ar,err);
	  System.out.println("after assert - in test2");
	  sa.assertAll();
  }
  
 
  
}
