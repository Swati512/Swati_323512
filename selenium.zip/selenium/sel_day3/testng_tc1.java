package sel_day3;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class testng_tc1 {
	
	//sel_21 ss=new sel_21();
	@BeforeMethod
	public void BM()
	{
		System.out.println("Before Method");
	}
	
	@AfterMethod
	public void AM()
	{
		System.out.println("After Method");
	}
	
  @Test(priority=2)
  public void a() 
  {
	  System.out.println("in a");
	 // f1();
	  //sel_21.display();
  }
  @Test(priority=1)
  
  public void z()
  {
	  System.out.println("in z");
  }
  
@Test(priority=3)
   public void b()
  {
	  System.out.println("in b");
  }


  

  
}
