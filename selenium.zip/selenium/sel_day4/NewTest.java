package sel_day4;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NewTest {
  @Test(dataProvider="logindataprovider")
  public void login(String eid,String pwd,String er) {
	  System.out.println(eid + " " + pwd + " " + er);
	  Assert.assertEquals("Girish",er);
  }
  @DataProvider(name="loginprovider")
  public String[][] get_testdata()
  {
	  String[][] logintestdata = {
			  {"girishindia95@gmail.com","mynewp@55","Girish"},
			  {"girishindia95@gmail.com","mynewp@55","Girish1"}
	  };
		return logintestdata;
	  
	  }
	  
  }
  
