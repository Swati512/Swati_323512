package sel_day4;

public class UserAction {

	String keyword;
	String xpath;
	String text_data;
	public UserAction(String keyword, String xpath, String text_data)
	{
		this.keyword = keyword;
		this.xpath = xpath;
		this.text_data = text_data;
	
}
}
