package sel_day5;



import java.util.logging.Logger;

import org.testng.annotations.Test;
//import org.testng.log4testng.Logger;

public class loggr {
 
	Logger log;
	
	@Test
	public void f()
	{
	log=Logger.getLogger("devpinoyLogger");
	log.info("test1 executed");
	}
	
	@Test
	public void f1()
	{
		log=Logger.getLogger("devpinoyLogger");
		log.info("test2 executed");
	}
}
