package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void f() {
 
//	  String ar="Noida",er="Noida";
//	   Assert.assertEquals(ar,er);
//	 System.out.println("working");
	 
	 System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
 dr.get("http://www.saucedemo.com");
 

 dr.findElement(By.id("user-name")).sendKeys("standard_user");
dr.findElement(By.id("password")).sendKeys("secret_sauce");
dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();
dr.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button")).click();
dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();
String s="Sauce Labs Backpack";
Assert.assertEquals(s,dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText());
//dr.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/button")).click();

  
  }
  
}

