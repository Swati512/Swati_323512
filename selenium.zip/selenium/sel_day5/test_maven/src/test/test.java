package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;


public class test {
  @Test
  public void f() {
	  
//	  String ar="Noida",er="Noida";
//	   Assert.assertEquals(ar,er);
//	 System.out.println("working");
	  System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
    dr.get("http://www.facebook.com");
  }
}
